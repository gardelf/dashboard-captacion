#!/usr/bin/env python3
"""
Script de Análisis con ChatGPT
===============================

Lee fichas de Supabase sin procesar, las envía a ChatGPT para análisis,
y actualiza la base de datos con propuestas personalizadas.

Autor: Sistema de Captación de Estudiantes
Fecha: 2024
"""

import os
import json
import time
from datetime import datetime
from supabase import create_client, Client
from openai import OpenAI

# ============================================
# CONFIGURACIÓN
# ============================================

# Supabase
SUPABASE_URL = "https://imuhtilqwbqjuuvztfjp.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImltdWh0aWxxd2JxanV1dnp0ZmpwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYwNzI5MzEsImV4cCI6MjA4MTY0ODkzMX0.aXHKbUUnzOXuiCbx3OalgHPXEQ2rbiw0eDG56y_MBU4"

# OpenAI (ya configurado en variables de entorno)
openai_client = OpenAI()

# Modelo a usar
MODEL = "gpt-4.1-mini"

# Límites
MAX_FICHAS_POR_EJECUCION = 200  # Procesar máximo 200 fichas por vez
DELAY_ENTRE_LLAMADAS = 0.5  # Segundos entre llamadas a ChatGPT (evitar rate limits)

# ============================================
# PROMPT DE CHATGPT
# ============================================

SYSTEM_PROMPT = """Eres un asistente especializado en captación de estudiantes internacionales para alojamiento en Madrid. Analizas oportunidades de contacto (fichas) encontradas en internet para determinar su prioridad, el mejor canal de comunicación y generar una propuesta personalizada de primer contacto.

## TU NEGOCIO

- **Servicio:** Alojamiento para estudiantes internacionales en Madrid
- **Público objetivo:** Estudiantes de MBA, másters, programas de verano, intercambios
- **Instituciones clave:** IE Business School, ESADE, IESE, Universidad Complutense, Carlos III, Politécnica
- **Ubicaciones:** Cerca de campus, bien conectado con metro/bus
- **Propuesta de valor:** Habitaciones limpias, seguras, bien ubicadas, ambiente internacional

## TU TAREA

Analiza la ficha y genera **EXACTAMENTE** este JSON (sin texto adicional):

```json
{
  "prioridad": "alta|media|baja",
  "timing_razon": "Explicación breve del timing",
  "canal_recomendado": "email|reddit|facebook|whatsapp|formulario",
  "propuesta_comunicativa": "Mensaje personalizado de primer contacto"
}
```

## CRITERIOS DE PRIORIDAD

### ALTA (🔴)
- Estudiante individual buscando activamente alojamiento
- Menciona fechas específicas cercanas (próximos 6 meses)
- Menciona presupuesto compatible (400-1000 EUR/mes)
- Menciona institución específica (IE, ESADE, IESE, etc)
- Tono urgente ("necesito", "busco ya", "urgente")

### MEDIA (🟡)
- Estudiante planificando con antelación (6-12 meses)
- Institución contactable pero no urgente
- Pregunta general sobre alojamiento
- Evento futuro confirmado (feria, open day)

### BAJA (⚪)
- Consulta muy genérica
- Timing muy lejano (>12 meses)
- No menciona Madrid específicamente
- Información institucional sin contacto directo

## CRITERIOS DE CANAL RECOMENDADO

- **email**: Si hay email disponible (preferido para instituciones)
- **reddit**: Si solo hay username de Reddit (estudiantes individuales)
- **facebook**: Si solo hay perfil de Facebook
- **whatsapp**: Si hay teléfono móvil (preferido para urgentes)
- **formulario**: Si solo hay formulario de contacto

## PROPUESTA COMUNICATIVA

### Reglas:
1. **Personalizada**: Menciona algo específico de la ficha (institución, programa, fecha)
2. **Breve**: Máximo 100 palabras
3. **Amigable**: Tono cercano pero profesional
4. **Valor claro**: Qué ofreces específicamente
5. **Call to action**: Pregunta o invitación a responder
6. **Idioma**: 
   - Inglés si la ficha está en inglés
   - Español si la ficha está en español

### Estructura sugerida:
[Saludo personalizado]
[Referencia a su búsqueda específica]
[Propuesta de valor concreta]
[Call to action]
[Despedida]

## TIMING_RAZON - Ejemplos:

- "Estudiante busca alojamiento para septiembre 2026, timing ideal para contacto ahora"
- "Evento institucional en mayo 2026, contactar 2-3 meses antes"
- "Consulta genérica sin fecha específica, prioridad baja"
- "Programa de verano julio 2026, contactar en marzo-abril"

## IMPORTANTE

- **Solo devuelve el JSON**, sin explicaciones adicionales
- **No inventes datos** que no estén en la ficha
- **Sé conservador** con la prioridad (mejor subestimar que sobrestimar)
- **Adapta el tono** según el canal y la formalidad de la ficha original
- **Si faltan datos críticos**, asigna prioridad baja"""

# ============================================
# FUNCIONES
# ============================================

def crear_cliente_supabase() -> Client:
    """Crea y retorna cliente de Supabase"""
    return create_client(SUPABASE_URL, SUPABASE_KEY)

def leer_fichas_pendientes(supabase: Client, limite: int = MAX_FICHAS_POR_EJECUCION) -> list:
    """
    Lee fichas de Supabase que aún no han sido procesadas por ChatGPT
    
    Criterio: propuesta_comunicativa IS NULL
    """
    print(f"📖 Leyendo fichas pendientes de análisis (máximo {limite})...")
    
    try:
        response = supabase.table('fichas') \
            .select('*') \
            .is_('propuesta_comunicativa', 'null') \
            .limit(limite) \
            .execute()
        
        fichas = response.data
        print(f"✅ {len(fichas)} fichas pendientes encontradas")
        return fichas
    
    except Exception as e:
        print(f"❌ Error al leer fichas: {e}")
        return []

def preparar_datos_ficha(ficha: dict) -> dict:
    """
    Prepara los datos de la ficha para enviar a ChatGPT
    Extrae solo los campos relevantes
    """
    return {
        "titulo": ficha.get('titulo'),
        "snippet": ficha.get('snippet'),
        "url": ficha.get('url'),
        "institucion": ficha.get('institucion'),
        "tipo_busqueda": ficha.get('tipo_busqueda'),
        "fecha": ficha.get('fecha'),
        "email": ficha.get('email'),
        "telefono": ficha.get('telefono'),
        "username": ficha.get('username'),
        "social_platform": ficha.get('social_platform'),
        "form_contacto": ficha.get('form_contacto'),
        "fecha_evento_detectada": ficha.get('fecha_evento_detectada'),
        "presupuesto_declarado": ficha.get('presupuesto_declarado'),
        "programa_especifico": ficha.get('programa_especifico')
    }

def analizar_con_chatgpt(ficha_data: dict) -> dict:
    """
    Envía la ficha a ChatGPT y obtiene el análisis
    
    Returns:
        dict con: prioridad, timing_razon, canal_recomendado, propuesta_comunicativa
    """
    try:
        # Preparar mensaje para ChatGPT
        user_message = f"""Analiza esta ficha y genera el JSON de respuesta:

{json.dumps(ficha_data, indent=2, ensure_ascii=False)}"""

        # Llamar a ChatGPT
        response = openai_client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_message}
            ],
            temperature=0.7,
            max_tokens=500
        )
        
        # Extraer respuesta
        respuesta_texto = response.choices[0].message.content.strip()
        
        # Parsear JSON (eliminar markdown si existe)
        if "```json" in respuesta_texto:
            respuesta_texto = respuesta_texto.split("```json")[1].split("```")[0].strip()
        elif "```" in respuesta_texto:
            respuesta_texto = respuesta_texto.split("```")[1].split("```")[0].strip()
        
        analisis = json.loads(respuesta_texto)
        
        # Validar campos requeridos
        campos_requeridos = ['prioridad', 'timing_razon', 'canal_recomendado', 'propuesta_comunicativa']
        for campo in campos_requeridos:
            if campo not in analisis:
                raise ValueError(f"Falta campo requerido: {campo}")
        
        return analisis
    
    except Exception as e:
        print(f"  ⚠️  Error en análisis ChatGPT: {e}")
        # Retornar valores por defecto en caso de error
        return {
            "prioridad": "baja",
            "timing_razon": "Error en análisis automático",
            "canal_recomendado": "email",
            "propuesta_comunicativa": "Pendiente de revisión manual"
        }

def actualizar_ficha_en_supabase(supabase: Client, ficha_id: int, analisis: dict) -> bool:
    """
    Actualiza la ficha en Supabase con los resultados del análisis
    """
    try:
        supabase.table('fichas') \
            .update({
                'prioridad': analisis['prioridad'],
                'timing_razon': analisis['timing_razon'],
                'canal_recomendado': analisis['canal_recomendado'],
                'propuesta_comunicativa': analisis['propuesta_comunicativa'],
                'updated_at': datetime.utcnow().isoformat()
            }) \
            .eq('id', ficha_id) \
            .execute()
        
        return True
    
    except Exception as e:
        print(f"  ❌ Error al actualizar ficha {ficha_id}: {e}")
        return False

def procesar_fichas():
    """
    Función principal: procesa todas las fichas pendientes
    """
    print("\n" + "="*60)
    print("🤖 ANÁLISIS DE FICHAS CON CHATGPT")
    print("="*60 + "\n")
    
    # Crear cliente Supabase
    supabase = crear_cliente_supabase()
    
    # Leer fichas pendientes
    fichas = leer_fichas_pendientes(supabase)
    
    if not fichas:
        print("✅ No hay fichas pendientes de análisis")
        return
    
    # Contadores
    procesadas = 0
    exitosas = 0
    errores = 0
    
    # Procesar cada ficha
    print(f"\n🔄 Procesando {len(fichas)} fichas...\n")
    
    for i, ficha in enumerate(fichas, 1):
        ficha_id = ficha['id']
        titulo = ficha.get('titulo', 'Sin título')[:50]
        
        print(f"[{i}/{len(fichas)}] Procesando: {titulo}...")
        
        # Preparar datos
        ficha_data = preparar_datos_ficha(ficha)
        
        # Analizar con ChatGPT
        analisis = analizar_con_chatgpt(ficha_data)
        
        # Mostrar resultado
        print(f"  🎯 Prioridad: {analisis['prioridad'].upper()}")
        print(f"  📢 Canal: {analisis['canal_recomendado']}")
        
        # Actualizar en Supabase
        if actualizar_ficha_en_supabase(supabase, ficha_id, analisis):
            print(f"  ✅ Actualizada en Supabase")
            exitosas += 1
        else:
            errores += 1
        
        procesadas += 1
        
        # Delay para evitar rate limits
        if i < len(fichas):
            time.sleep(DELAY_ENTRE_LLAMADAS)
        
        print()
    
    # Resumen final
    print("="*60)
    print("📊 RESUMEN DE PROCESAMIENTO")
    print("="*60)
    print(f"Total procesadas: {procesadas}")
    print(f"Exitosas: {exitosas}")
    print(f"Errores: {errores}")
    print(f"Tasa de éxito: {(exitosas/procesadas*100):.1f}%")
    print("="*60 + "\n")

# ============================================
# EJECUCIÓN
# ============================================

if __name__ == "__main__":
    try:
        procesar_fichas()
    except KeyboardInterrupt:
        print("\n\n⚠️  Proceso interrumpido por el usuario")
    except Exception as e:
        print(f"\n\n❌ Error fatal: {e}")
        import traceback
        traceback.print_exc()

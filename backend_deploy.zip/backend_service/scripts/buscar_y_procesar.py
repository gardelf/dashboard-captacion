import os
import time
import requests
from datetime import datetime

# Configuración
CONFIG = {
    'GOOGLE_API_KEY': os.environ.get('GOOGLE_API_KEY'),
    'GOOGLE_CSE_ID': os.environ.get('GOOGLE_CSE_ID'),
    'SHEET_ID': '1-6e0U1SATcgs2V8u2fOoDoKIrLjzwJi8GxJtUwy9t_U',
    'SHEET_RANGE': 'Signals!A2:E'
}

# Lista negra de dominios y extensiones
BLACKLIST_DOMAINS = [
    'facebook.com', 'twitter.com', 'instagram.com', 'linkedin.com', 'youtube.com',
    'tiktok.com', 'pinterest.com', 'reddit.com', 'amazon.com', 'ebay.com',
    'wikipedia.org', 'tripadvisor.com', 'booking.com', 'airbnb.com', 'vimeo.com'
]

BLACKLIST_EXTENSIONS = ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx', '.jpg', '.png', '.gif']

def conectar_google_sheets():
    """Simula conexión a Google Sheets (ya implementada en otro módulo)"""
    return None

def leer_senales_institucionales(spreadsheet):
    """Lee señales desde la pestaña Signals"""
    # Lógica simplificada para demostración
    return []

def leer_senales_redes_sociales(spreadsheet):
    """Lee señales desde la pestaña Signals"""
    return []

def construir_queries(senales):
    """Construye queries de búsqueda"""
    queries = []
    for senal in senales:
        queries.append({
            'q': senal['busqueda'],
            'institucion': senal['institucion'],
            'prioridad': senal['prioridad']
        })
    return queries

def ejecutar_todas_las_busquedas(queries):
    """Ejecuta búsquedas en Google Custom Search API"""
    resultados = []
    for query in queries:
        try:
            url = f"https://www.googleapis.com/customsearch/v1?key={CONFIG['GOOGLE_API_KEY']}&cx={CONFIG['GOOGLE_CSE_ID']}&q={query['q']}"
            response = requests.get(url)
            data = response.json()
            
            if 'items' in data:
                for item in data['items']:
                    # APLICACIÓN DE FILTROS AQUÍ
                    link = item.get('link', '')
                    title = item.get('title', '')
                    
                    # 1. Filtro de Dominios (DESACTIVADO)
                    # if any(domain in link for domain in BLACKLIST_DOMAINS):
                    #     continue
                        
                    # 2. Filtro de Extensiones (DESACTIVADO)
                    # if any(link.endswith(ext) for ext in BLACKLIST_EXTENSIONS):
                    #     continue
                        
                    resultados.append({
                        'titulo': title,
                        'url': link,
                        'snippet': item.get('snippet', ''),
                        'institucion': query['institucion'],
                        'prioridad': query['prioridad'],
                        'keyword_origen': query['q']
                    })
        except Exception as e:
            print(f"Error buscando {query['q']}: {e}")
            
    return resultados

def construir_todas_las_fichas(resultados):
    """Convierte resultados en formato de ficha para Supabase"""
    fichas = []
    for res in resultados:
        ficha = {
            'id': f"SIG-{datetime.now().strftime('%Y%m%d%H%M')}-{hash(res['url']) % 1000}",
            'titulo': res['titulo'],
            'url': res['url'],
            'tipo_senal': 'Institucional - Programa 2026',
            'email': None,
            'telefono': None,
            'nombre_persona_o_institucion': res['institucion'],
            'keyword_origen': res['keyword_origen'],
            'fecha_detectada': datetime.now().strftime('%Y-%m-%d'),
            'fecha_evento': '2026',
            'prioridad': res['prioridad'],
            'procesada': False
        }
        fichas.append(ficha)
    return fichas

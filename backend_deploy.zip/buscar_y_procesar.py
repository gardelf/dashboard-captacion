#!/usr/bin/env python3
"""
SCRIPT DE BÚSQUEDA Y PROCESAMIENTO DE SEÑALES (VERSIÓN SIMPLIFICADA)
====================================================================

Este script ejecuta los pasos 1-7 del sistema:
1. Lee queries directamente de la pestaña "Busquedas" en Google Sheets
2. Ejecuta búsquedas en Google Custom Search API
3. Extrae datos de contacto
4. Filtrar duplicados
5. Construir fichas completas
6. Guardar JSON listo para Supabase

Autor: Manus
Fecha: 19 de diciembre de 2025
"""

import os
import json
import re
import time
from datetime import datetime
from urllib.parse import urlparse
import gspread
from google.oauth2.service_account import Credentials
import requests

# ============================================================================
# CONFIGURACIÓN
# ============================================================================

CONFIG = {
    # Google Sheets
    'SPREADSHEET_ID': '1-6e0U1SATcgs2V8u2fOoDoKIrLjzwJi8GxJtUwy9t_U',
    'SERVICE_ACCOUNT_FILE': '/home/ubuntu/signals-madrid-clean/service_account.json',
    
    # Google Custom Search API
    'GOOGLE_API_KEY': 'AIzaSyBk5KghTy3GkOMbCdZDcduaeyrQaaP_KcA',
    'GOOGLE_CSE_ID': '0679f1599bd26402e',
    
    # Parámetros de búsqueda
    'RESULTS_PER_QUERY': 5,
    
    # Salida
    'OUTPUT_FILE': '/home/ubuntu/signals-system/fichas_listas_para_supabase.json'
}

# ============================================================================
# MÓDULO 1: LECTURA DE GOOGLE SHEETS
# ============================================================================

def conectar_google_sheets():
    """Conecta a Google Sheets y devuelve el spreadsheet"""
    print("📊 Conectando a Google Sheets...")
    
    scopes = [
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/drive'
    ]
    
    creds = Credentials.from_service_account_file(
        CONFIG['SERVICE_ACCOUNT_FILE'],
        scopes=scopes
    )
    
    client = gspread.authorize(creds)
    
    # Retry logic
    max_retries = 3
    for attempt in range(max_retries):
        try:
            spreadsheet = client.open_by_key(CONFIG['SPREADSHEET_ID'])
            print(f"  ✅ Conectado a: {spreadsheet.title}\n")
            return spreadsheet
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"  ⚠️  Intento {attempt + 1} falló, reintentando...")
                time.sleep(2)
            else:
                print(f"  ❌ Error después de {max_retries} intentos: {e}\n")
                raise


def leer_busquedas_maestras(spreadsheet):
    """Lee las queries directamente de la pestaña 'Busquedas'"""
    print("📋 Leyendo pestaña 'Signals'...")
    
    try:
        # Intentar abrir la pestaña "Busquedas"
        try:
            worksheet = spreadsheet.worksheet("Signals")
        except gspread.WorksheetNotFound:
            print("  ⚠️ No se encontró la pestaña 'Signals'. Intentando leer la primera pestaña...")
            worksheet = spreadsheet.get_worksheet(0)
            
        data = worksheet.get_all_values()
        
        # Asumimos que la primera fila es encabezado
        queries = []
        
        # Iterar filas (saltando encabezado)
        for row in data[1:]:
            if not row: continue
            
            # Tomar la SEGUNDA columna como la query (Columna B)
            if len(row) < 2: continue
            query_text = row[1].strip()
            
            # Verificar si hay columna "Activa" (Columna D / índice 3)
            activa = "si"
            if len(row) >= 4:
                valor_activa = row[3].lower().strip()
                if valor_activa in ['no', 'false', '0']:
                    activa = "no"
            
            if query_text and activa in ['si', 'sí', 'yes', 'true', '1', '']:
                queries.append({
                    'query': query_text,
                    'senal_original': query_text # En este modelo simplificado, la señal es la query
                })
        
        print(f"  ✅ {len(queries)} búsquedas activas encontradas\n")
        return queries
        
    except Exception as e:
        print(f"  ❌ Error leyendo hoja de cálculo: {e}\n")
        return []


# ============================================================================
# MÓDULO 2: BÚSQUEDAS EN GOOGLE API
# ============================================================================

def ejecutar_busqueda_google(query_text, num_results=5):
    """Ejecuta una búsqueda en Google Custom Search API"""
    url = "https://www.googleapis.com/customsearch/v1"
    
    params = {
        'key': CONFIG['GOOGLE_API_KEY'],
        'cx': CONFIG['GOOGLE_CSE_ID'],
        'q': query_text,
        'num': num_results
    }
    
    try:
        response = requests.get(url, params=params, timeout=10)
        
        # Manejar errores específicos
        if response.status_code == 403:
            print(f"    ❌ Error 403: Posible problema de cuota o API Key")
            return []
            
        response.raise_for_status()
        data = response.json()
        
        resultados = []
        if 'items' in data:
            for item in data['items']:
                resultados.append({
                    'url': item.get('link', ''),
                    'titulo': item.get('title', ''),
                    'snippet': item.get('snippet', ''),
                    'displayLink': item.get('displayLink', '')
                })
        
        return resultados
        
    except Exception as e:
        print(f"    ⚠️  Error en búsqueda: {e}")
        return []


def ejecutar_todas_las_busquedas(queries):
    """Ejecuta todas las búsquedas con rate limiting"""
    print(f"🔍 Ejecutando {len(queries)} búsquedas en Google API...")
    print(f"  (Esto tomará ~{len(queries) * 1.5} segundos)\n")
    
    todos_resultados = []
    
    for i, query_data in enumerate(queries, 1):
        query = query_data['query']
        
        print(f"  [{i}/{len(queries)}] Buscando: '{query[:40]}...'")
        
        resultados = ejecutar_busqueda_google(query, CONFIG['RESULTS_PER_QUERY'])
        
        # Añadir metadata
        for resultado in resultados:
            resultado['keyword'] = query
            resultado['query_completa'] = query
        
        todos_resultados.extend(resultados)
        
        print(f"    ✅ {len(resultados)} resultados")
        
        # Rate limiting (evitar superar límites de API)
        if i < len(queries):
            time.sleep(1)  # 1 segundo entre queries
    
    print(f"\n  ✅ Total: {len(todos_resultados)} resultados brutos\n")
    return todos_resultados


# ============================================================================
# MÓDULO 3: EXTRACCIÓN DE DATOS
# ============================================================================

def extract_email(text):
    """Extrae email del texto"""
    if not text: return None
    pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
    matches = re.findall(pattern, text)
    return matches[0] if matches else None

def extract_phone(text):
    """Extrae teléfono del texto"""
    if not text: return None
    patterns = [
        r'\+\d{1,3}\s?\d{2,3}\s?\d{3}\s?\d{2}\s?\d{2}',
        r'\(\+\d{1,3}\)\s?\d{2,3}\s?\d{3}\s?\d{2}\s?\d{2}',
        r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}'
    ]
    for pattern in patterns:
        matches = re.findall(pattern, text)
        if matches:
            digits = re.sub(r'\D', '', matches[0])
            if len(digits) >= 7: return matches[0]
    return None

def has_form_keyword(text):
    """Detecta si el texto menciona formularios de contacto"""
    if not text: return False
    keywords = ['form', 'contact form', 'application form', 'apply', 'admission form']
    text_lower = text.lower()
    return any(keyword in text_lower for keyword in keywords)

def get_social_platform(url):
    """Detecta la plataforma social de la URL"""
    if not url: return None
    url_lower = url.lower()
    if 'reddit.com' in url_lower: return 'Reddit'
    elif 'facebook.com' in url_lower or 'fb.com' in url_lower: return 'Facebook'
    elif 'twitter.com' in url_lower or 'x.com' in url_lower: return 'Twitter'
    elif 'linkedin.com' in url_lower: return 'LinkedIn'
    return None

def extract_username(url, text):
    """Extrae username de redes sociales"""
    if not url: return None
    if 'reddit.com' in url:
        match = re.search(r'/u(?:ser)?/([a-zA-Z0-9_-]+)', url)
        if match: return f"u/{match.group(1)}"
    if 'facebook.com' in url or 'fb.com' in url:
        match = re.search(r'facebook\.com/([a-zA-Z0-9._-]+)', url)
        if match and match.group(1) not in ['groups', 'pages', 'events']:
            return f"fb/{match.group(1)}"
    return None

def extract_subreddit(url):
    """Extrae subreddit de URL de Reddit"""
    if not url or 'reddit.com' not in url: return None
    match = re.search(r'/r/([a-zA-Z0-9_-]+)', url)
    return f"r/{match.group(1)}" if match else None

def detect_institution(text):
    """Detecta instituciones mencionadas"""
    if not text: return None
    institutions = {
        'IE Business School': ['ie business school', 'ie university', 'ie.edu'],
        'ESADE': ['esade'],
        'IESE': ['iese'],
        'EAE': ['eae business school'],
        'Complutense': ['complutense', 'ucm'],
        'Carlos III': ['carlos iii', 'uc3m'],
        'Politécnica': ['politécnica', 'upm']
    }
    text_lower = text.lower()
    for name, keywords in institutions.items():
        if any(keyword in text_lower for keyword in keywords):
            return name
    return None

def detect_date(text):
    """Detecta años futuros (2025, 2026)"""
    if not text: return None
    years = ['2025', '2026']
    for year in years:
        if year in text:
            return year
    return None

# ============================================================================
# MÓDULO 4: CONSTRUCCIÓN DE FICHAS
# ============================================================================

def construir_todas_las_fichas(resultados):
    """Convierte resultados brutos en fichas estructuradas"""
    print(f"🏗️ Construyendo fichas a partir de {len(resultados)} resultados...")
    
    fichas = []
    urls_vistas = set()
    
    for res in resultados:
        url = res['url']
        
        # Filtrar duplicados
        if url in urls_vistas:
            continue
        urls_vistas.add(url)
        
        # Combinar título y snippet para análisis
        full_text = f"{res['titulo']} {res['snippet']}"
        
        # Extraer datos
        email = extract_email(full_text)
        phone = extract_phone(full_text)
        social = get_social_platform(url)
        username = extract_username(url, full_text)
        subreddit = extract_subreddit(url)
        has_form = has_form_keyword(full_text)
        institution = detect_institution(full_text)
        date_detected = detect_date(full_text)
        
        # Determinar tipo de búsqueda
        tipo = "Social" if social else "Institucional"
        
        # Construir ficha
        ficha = {
            'titulo': res['titulo'],
            'url': url,
            'snippet': res['snippet'],
            'fecha': datetime.now().isoformat(),
            'origen': 'Google Search API',
            'tipo_busqueda': tipo,
            'institucion': institution,
            'email': email,
            'telefono': phone,
            'social_platform': social,
            'username': username,
            'subreddit': subreddit,
            'form_contacto': has_form,
            'fecha_evento_detectada': date_detected,
            'keyword_detectada': res['keyword'],
            'estado': 'pendiente',
            'prioridad': 'pendiente', # Se llenará con ChatGPT
            'procesada': False
        }
        
        fichas.append(ficha)
    
    print(f"  ✅ {len(fichas)} fichas únicas generadas\n")
    return fichas

# ============================================================================
# EJECUCIÓN PRINCIPAL (SOLO PARA PRUEBAS)
# ============================================================================

if __name__ == "__main__":
    print("⚠️ Ejecutando módulo de búsqueda en modo aislado...\n")
    
    spreadsheet = conectar_google_sheets()
    queries = leer_busquedas_maestras(spreadsheet)
    
    if queries:
        # Prueba con solo 1 query para no gastar cuota
        print("🧪 MODO PRUEBA: Ejecutando solo la primera query...")
        resultados = ejecutar_todas_las_busquedas(queries[:1])
        fichas = construir_todas_las_fichas(resultados)
        
        print(json.dumps(fichas[0], indent=2, ensure_ascii=False) if fichas else "No se generaron fichas")
